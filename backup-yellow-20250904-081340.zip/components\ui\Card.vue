﻿<template>
  <div class="rounded-xl border border-white/10 bg-white/5 hover:bg-white/[0.07] transition-colors">
    <slot />
  </div>
</template>

