﻿<template>
  <div class="min-h-dvh flex items-center justify-center p-8">
    <div class="max-w-md w-full space-y-4 text-center">
      <h1 class="text-2xl font-semibold">Login</h1>
      <p class="text-sm text-gray-500">Auth flow coming soon.</p>
      <NuxtLink to="/" class="inline-flex px-4 py-2 rounded bg-black text-white">
  Go to Home
</NuxtLink>

    </div>
  </div>
</template>

