﻿<script setup lang="ts"></script>

<template>
  <div class="rounded-xl border border-white/10 bg-white/[0.04] p-6 text-center">
    <p class="text-sm text-muted-foreground">
      Advertisement â€” Powered by <span class="font-semibold">Matterport</span>
    </p>
    <a
      href="https://matterport.com"
      target="_blank"
      rel="noopener"
      class="mt-3 inline-block px-4 py-2 rounded-lg bg-xplor-yellow text-black hover:opacity-90"
    >
      Learn more
    </a>
  </div>
</template>

