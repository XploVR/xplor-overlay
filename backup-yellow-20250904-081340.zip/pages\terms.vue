﻿<template>
  <div class="max-w-4xl mx-auto p-6 space-y-4">
    <h1 class="text-2xl font-semibold">Terms & Conditions</h1>
    <p class="text-gray-600">Developer placeholder. Replace with your real terms.</p>
    <ul class="list-disc pl-6 space-y-2">
      <li>Use of the site is at your own risk.</li>
      <li>Content is provided â€œas isâ€ during development.</li>
      <li>Data may be test data while in dev mode.</li>
    </ul>
  </div>
</template>

