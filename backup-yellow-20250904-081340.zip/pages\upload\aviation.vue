﻿<script setup lang="ts">
import FormsUploadWithMedia from '~/components/forms/UploadWithMedia.vue'
</script>

<template>
  <div class="w-full px-4 md:px-6 lg:px-8 py-8 space-y-6 max-w-3xl mx-auto">
    <h1 class="text-2xl font-semibold">New Aviation Listing</h1>
    <FormsUploadWithMedia kind="real_estate" />
  </div>
</template>

