﻿<script setup lang="ts">
definePageMeta({ layout: 'default' })
</script>

<template>
  <div class="container-x py-10 space-y-4">
    <h1 class="text-2xl font-semibold">Alerts</h1>
    <p class="text-white/70">Your notifications and system alerts will appear here.</p>
    <div class="rounded-xl border border-white/10 p-6 bg-white/[0.03]">
      <p class="text-white/60">No alerts yet.</p>
    </div>
  </div>
</template>

