﻿<script setup lang="ts">
definePageMeta({ layout: 'default' })
</script>
<template>
  <div class="container-x py-8 text-white">
    <h1 class="text-3xl font-semibold">Equipment & Specs</h1>
    <p class="text-white/70 mt-2">Recommended gear and standards.</p>
  </div>
</template>


