﻿<template>
  <div class="max-w-4xl mx-auto p-6 space-y-4">
    <h1 class="text-2xl font-semibold">Privacy Policy</h1>
    <p class="text-gray-600">Developer placeholder. Replace with your real policy.</p>
    <p>We do not collect personal data in dev mode. Real policy goes here.</p>
  </div>
</template>

