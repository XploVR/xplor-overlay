﻿<template>
  <div class="max-w-6xl mx-auto p-6 space-y-4">
    <h1 class="text-2xl font-semibold">Contact</h1>
    <p class="text-gray-600">Drop us a line at hello@xplor.io</p>
  </div>
</template>

