﻿<script setup lang="ts">
</script>

<template>
  <div class="max-w-3xl mx-auto p-6 space-y-6">
    <h1 class="text-2xl font-semibold">Upload — Real Estate</h1>
    <FormsUploadWithMedia kind="real_estate" />
  </div>
</template>

