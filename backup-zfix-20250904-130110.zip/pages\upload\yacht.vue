﻿<script setup lang="ts">
import UploadWithMedia from '~/components/forms/UploadWithMedia.vue'
</script>

<template>
  <div class="max-w-3xl mx-auto p-6">
    <h1 class="text-2xl font-semibold mb-4">Upload â€” Yacht</h1>
    <UploadWithMedia kind="yacht" />
  </div>
</template>

