﻿<template>
  <div class="max-w-3xl mx-auto p-6 space-y-4">
    <h1 class="text-2xl font-semibold">Add a Space</h1>
    <p class="text-gray-600">Form placeholder. Hook up later.</p>
    <button class="px-3 py-1.5 rounded-xl border hover:bg-gray-50">Save Draft</button>
  </div>
</template>

